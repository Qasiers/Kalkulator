<?php

namespace app\controllers;

class variable {
    public $number;
    public $random;
}