<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Validator;
require_once 'Variables.class.php';

class Main {

    public $variable;
    public $isAllRight;

    public function __construct() {
        $this->variable = new variable();
    }

    public function getValues() {
        $this->variable->number = isset($_POST['number'])?$_POST['number']:null;
        $this->variable->random = isset($_SESSION['random'])?$_SESSION['random']:null;
    }

    public function isALLRight() {
        $isAllRight = new Validator();
        $this->int = $isAllRight->validateFromPost('number', [
            'required' => true,
            'required_massage' => 'Nie podano wartości. ',
            'numeric' => true,
            'int' => true,
            'validator_massage' => 'Podana wartość nie jest liczbą całkowitą. ',
            'masseage_type' => error, 
        ]);
    }

    public function operation() {
        session_start();
        if(!isset($_SESSION['random'])) {
            $_SESSION['random'] = rand(0,9);
        }
        
        $this->getValues();

        if ($this->isALLRight()) {
        
            if ($this->variable->number ==  $this->variable->random) {
                App::getMessages()->addMessage(new Message('Brawo! Szukana liczba to '. $this->variable->random.'. ', Message::INFO));
                unset($_SESSION['random']);
            }
    
            if ($this->variable->number <  $this->variable->random) {
                App::getMessages()->addMessage(new Message('Zgaduj dalej. Podano za małą liczbę. ', Message::INFO));
            }
    
            if ($this->variable->number >  $this->variable->random) {
                App::getMessages()->addMessage(new Message('Zgaduj dalej. Podano za dużą liczbę. ', Message::INFO));
            }
        }

        $this->generateView();
	}
		
	public function generateView(){
		$smarty = new Smarty();
		
		$smarty->assign('page_title','Zgadywanka od 0 do 9');
		$smarty->assign('page_header','Zgadywanka od 0 do 9');
				
		$smarty->assign('variable',$this->variable);
		
		$smarty->display('Guest.html');
	} 
}