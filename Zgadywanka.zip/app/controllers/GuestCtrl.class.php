<?php

namespace app\controllers;

use core\App;

class GuestCtrl {
    public function action_guest() {

        App::getSmarty()->display("Guest.html");

    }
}
