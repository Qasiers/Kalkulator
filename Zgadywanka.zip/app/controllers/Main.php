<?php

require_once 'Form.class.php';

$form = new Main();
$form->operation();